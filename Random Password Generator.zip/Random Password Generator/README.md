# Advanced Random Password Generator

## 1. Project Title
**Advanced Random Password Generator**

## 2. Project Objective
This project was developed as **Internship Task 3**. The objective was to design and implement a professional, secure desktop application capable of generating highly secure, customizable passwords while providing a smooth and accessible user experience.

## 3. Project Description
The Advanced Random Password Generator is a Python-based desktop application featuring a modern Tkinter Graphical User Interface (GUI). It allows users to generate complex passwords based on customizable criteria, evaluate their relative strength, and manage them during a live session without compromising security by writing sensitive data to disk.

## 4. Features
* **Customizable Length**: Choose between 8 and 128 characters.
* **Character Diversity**: Toggle uppercase, lowercase, numbers, and symbols.
* **Guaranteed Inclusion**: Ensures at least one character from every selected category is actually present in the final password.
* **Visual Strength Indicator**: Color-coded progress bar (Weak/Medium/Strong).
* **One-Click Copy**: Seamless integration with the operating system clipboard.
* **Ambiguous Character Filter**: Exclude confusing characters to make passwords easier to read.
* **Session-Only History**: Keep track of the last 5 passwords generated during your current session.
* **Robust Error Handling**: Safely intercepts invalid inputs and system errors without crashing.

## 5. Technologies Used
* **Python 3**: Core programming language.
* **Tkinter & ttk**: For building the native, cross-platform graphical user interface.
* **secrets module**: Built-in library for cryptographic randomness.
* **string module**: For standard character set definitions.
* **pyperclip**: External library for cross-platform clipboard interactions.

## 6. Why `secrets` is Used Instead of `random`
The standard Python `random` module uses the Mersenne Twister algorithm. It is designed for modeling and simulation, making it highly predictable—if an attacker observes a sequence of outputs, they can theoretically predict past and future generated values. The `secrets` module, on the other hand, hooks directly into the operating system's strongest cryptographic randomness source (e.g., `/dev/urandom`), ensuring that the generated passwords are mathematically secure and unpredictable.

## 7. Password Generation Workflow
1. **Validation**: The system first verifies that the requested length is valid ($\ge$ 8) and at least two character types are selected.
2. **Pool Construction**: Character pools are built and (if requested) scrubbed of ambiguous characters.
3. **Guaranteed Seeding**: The algorithm securely picks exactly one character from *each* selected pool to guarantee diversity.
4. **Random Fill**: The remaining length of the password is filled randomly from the combined pool of allowed characters.
5. **Cryptographic Shuffle**: Because the guaranteed characters are initially grouped at the start of the string, the algorithm performs a secure Fisher-Yates shuffle using `secrets.randbelow()` to randomize the final order.

## 8. Password Strength Indicator
The application features a color-coded visual progress bar that estimates password strength based on length and character diversity.
> **IMPORTANT:** This strength indicator is an *approximate user-facing guide* designed to encourage better password habits. It does not calculate perfect mathematical entropy and should not be treated as a definitive security measurement.

## 9. Clipboard Functionality
* **Automatic Copying**: Every time a new password is generated, it is silently and automatically pushed to your system clipboard for immediate pasting.
* **Manual Copying**: Users can manually copy the active password, or any password from the history list, using the "Copy" buttons. 
* **Failsafes**: If the OS denies clipboard access, the app catches the error gracefully and alerts the user rather than crashing.

## 10. Ambiguous Character Exclusion
When the **"Exclude Ambiguous Characters"** checkbox is enabled, the characters `0`, `O`, `l`, and `1` are fundamentally stripped from the generation pools *before* any characters are selected. This ensures that the generated password will never contain confusing look-alikes, while still maintaining the cryptographic guarantee of diversity.

## 11. Session-Only Password History
The application temporarily remembers the last 5 passwords you generated in case you accidentally overwrite your clipboard. 
* This data is stored strictly in the application's active RAM.
* Absolutely **no passwords** are logged to the console, saved to SQLite, exported to CSV, or written to any permanent file.
* Once the application window is closed, the history ceases to exist.

## 12. Project Structure
```text
Random Password Generator/
│
├── main.py              # Application entry point
├── gui.py               # Tkinter layout and UI event logic
├── generator.py         # Core cryptographic generation engine
├── validation.py        # Input validation logic
├── strength.py          # Password strength estimation logic
├── requirements.txt     # External dependencies list
└── README.md            # Project documentation
```

## 13. Installation Requirements
* Python 3.6 or higher
* `pip` package manager

## 14. Installation Commands
Clone or download the project folder, open your terminal/command prompt, and navigate to the directory. Install the required dependencies:
```shell
pip install -r requirements.txt
```

## 15. How to Run the Application
Start the graphical interface by executing the main script:
```shell
python main.py
```

## 16. Example Usage
1. Open the application.
2. Use the slider or text box to set your desired password length (e.g., 24).
3. Check the boxes for the character types you need (e.g., Uppercase, Lowercase, Numbers, Symbols).
4. Click **Generate Password**.
5. The password will appear on the screen, the strength bar will update to Green (Strong), and the password will be silently copied to your clipboard.
6. Paste your new secure password wherever you need it!

## 17. Security Considerations
* **Memory Management**: Passwords are kept in memory and exposed to the clipboard. Be aware that clipboard manager applications running on your machine may retain clipboard history.
* **Shuffle Algorithm**: The standard `random.shuffle()` is avoided entirely in favor of a custom, cryptographically secure Fisher-Yates implementation.

## 18. Limitations
* The strength indicator is a basic heuristic (length + character types) and does not cross-reference passwords against known dictionary breaches (like HaveIBeenPwned).
* The security of the generated password is ultimately dependent on the security of the host operating system's random number generator.

## 19. Future Improvements
* Add rigorous entropy calculation (measured in bits).
* Introduce a master-password protected SQLite vault for permanent (but encrypted) password storage.
* Add an option to generate memorable passphrase-style passwords (e.g., `correct-horse-battery-staple`).

## 20. Author Section
Developed by **Omraj** as part of Internship Task 3.

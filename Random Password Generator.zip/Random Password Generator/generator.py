import secrets

def generate_password(length, use_upper, use_lower, use_numbers, use_symbols, exclude_ambiguous):
    """
    Generates a cryptographically secure password based on selected criteria.
    
    Security Decisions:
    - Uses the 'secrets' module instead of 'random'. The 'random' module is predictable 
      and not suitable for cryptography.
    - Uses secrets.choice() for selecting individual characters.
    - Avoids random.shuffle() as it relies on the predictable random module. Instead, 
      it implements a secure Fisher-Yates shuffle using secrets.randbelow().
    - Guarantees at least one character from every selected pool by seeding the 
      first few characters explicitly.
    """
    
    # 1. Handle invalid inputs safely
    if not isinstance(length, int) or length < 8:
        raise ValueError("Password length must be an integer of at least 8.")
        
    types_count = sum([bool(use_upper), bool(use_lower), bool(use_numbers), bool(use_symbols)])
    if types_count < 2:
        raise ValueError("At least two character types must be selected.")
        
    # 2. Base character sets
    upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    lower = "abcdefghijklmnopqrstuvwxyz"
    numbers = "0123456789"
    # Safe set of common password symbols as requested
    symbols = "!@#$%^&*()-_=+[]{};:,.?/"
    
    # 3. Exclude ambiguous characters
    if exclude_ambiguous:
        ambiguous = "0O1l"
        upper = "".join([c for c in upper if c not in ambiguous])
        lower = "".join([c for c in lower if c not in ambiguous])
        numbers = "".join([c for c in numbers if c not in ambiguous])
        symbols = "".join([c for c in symbols if c not in ambiguous])

    pools = []
    if use_upper:
        pools.append(upper)
    if use_lower:
        pools.append(lower)
    if use_numbers:
        pools.append(numbers)
    if use_symbols:
        pools.append(symbols)
        
    password_chars = []
    
    # 4. Guarantee at least one character from each selected pool
    for pool in pools:
        if pool:
            password_chars.append(secrets.choice(pool))
            
    # 5. Combine all allowed pools for the remaining characters
    all_allowed = "".join(pools)
    if not all_allowed:
        raise ValueError("No characters available to generate password after exclusions.")
        
    # 6. Fill the remaining length securely
    remaining_length = length - len(password_chars)
    for _ in range(remaining_length):
        password_chars.append(secrets.choice(all_allowed))
        
    # 7. Securely shuffle the password characters (Fisher-Yates shuffle)
    # We do NOT use random.shuffle() because it is not cryptographically secure.
    for i in range(len(password_chars) - 1, 0, -1):
        # Pick a cryptographically secure random index from 0 to i inclusive
        j = secrets.randbelow(i + 1)
        # Swap the characters
        password_chars[i], password_chars[j] = password_chars[j], password_chars[i]
        
    return "".join(password_chars)


def evaluate_strength(length, types_count):
    """
    Evaluates password strength based on length and character types used.
    Returns 'Weak', 'Medium', or 'Strong'.
    """
    if length >= 12 and types_count >= 3:
        return "Strong"
    elif length >= 8 and types_count >= 2:
        return "Medium"
    else:
        return "Weak"

import tkinter as tk
from tkinter import ttk, messagebox
import pyperclip
from datetime import datetime
from validation import validate_password_options
from generator import generate_password
from strength import evaluate_password_strength

class PasswordGeneratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Secure Password Generator")
        self.root.geometry("450x620")
        self.root.minsize(400, 580)
        
        # Apply ttk style theme
        self.style = ttk.Style()
        if 'clam' in self.style.theme_names():
            self.style.theme_use('clam')
            
        self._configure_styles()
        
        self.history = []
        
        # Modular UI construction
        self._setup_ui()
        
    def _configure_styles(self):
        """Configures custom ttk styles for consistent and professional appearance."""
        # Use standard, non-oversized Windows fonts
        font_main = ("Segoe UI", 10)
        font_header = ("Segoe UI", 16, "bold")
        font_subtitle = ("Segoe UI", 10, "italic")
        font_label = ("Segoe UI", 11, "bold")

        self.style.configure("TFrame", background="#f8f9fa")
        
        self.style.configure("TLabel", font=font_main, background="#f8f9fa", foreground="#333333")
        self.style.configure("Header.TLabel", font=font_header, foreground="#2c3e50", background="#f8f9fa")
        self.style.configure("Subtitle.TLabel", font=font_subtitle, foreground="#7f8c8d", background="#f8f9fa")
        self.style.configure("Section.TLabel", font=font_label, foreground="#2c3e50", background="#f8f9fa")
        self.style.configure("Strength.TLabel", font=("Segoe UI", 10, "bold"), background="#f8f9fa")
        
        self.style.configure("TCheckbutton", font=font_main, background="#f8f9fa", focuscolor="#f8f9fa")
        
        self.style.configure("TButton", font=font_main, padding=5)
        self.style.configure("Generate.TButton", font=("Segoe UI", 11, "bold"), padding=8)
        
        self.root.configure(bg="#f8f9fa")

    def _setup_ui(self):
        """Builds the main user interface."""
        # Main container with balanced padding
        main_frame = ttk.Frame(self.root, padding="20 20 20 20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 1. Header
        ttk.Label(main_frame, text="Secure Password Generator", style="Header.TLabel").pack(anchor=tk.W)
        ttk.Label(main_frame, text="Create a strong password easily", style="Subtitle.TLabel").pack(anchor=tk.W, pady=(0, 20))
        
        # Separator
        ttk.Separator(main_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(0, 15))
        
        # 2. Password Length Section
        self._build_length_section(main_frame)
        
        # 3. Character Types Section
        self._build_character_types_section(main_frame)
        
        # Separator
        ttk.Separator(main_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=15)
        
        # 4. Password Result Section
        self._build_result_section(main_frame)
        
        # 5. Action Buttons Section
        self._build_buttons_section(main_frame)

    def _build_length_section(self, parent):
        ttk.Label(parent, text="Password Length", style="Section.TLabel").pack(anchor=tk.W, pady=(0, 5))
        
        self.length_var = tk.IntVar(value=16)
        
        length_inner = ttk.Frame(parent)
        length_inner.pack(fill=tk.X, pady=(0, 15))
        
        self.length_spinbox = ttk.Spinbox(length_inner, from_=8, to=128, textvariable=self.length_var, width=5, font=("Segoe UI", 10))
        self.length_spinbox.pack(side=tk.LEFT, padx=(0, 15))
        
        length_scale = ttk.Scale(length_inner, from_=8, to=128, variable=self.length_var, orient=tk.HORIZONTAL)
        length_scale.pack(side=tk.LEFT, fill=tk.X, expand=True)

    def _build_character_types_section(self, parent):
        ttk.Label(parent, text="Choose what to include", style="Section.TLabel").pack(anchor=tk.W, pady=(0, 5))
        
        self.var_upper = tk.BooleanVar(value=True)
        self.var_lower = tk.BooleanVar(value=True)
        self.var_numbers = tk.BooleanVar(value=True)
        self.var_symbols = tk.BooleanVar(value=True)
        
        grid_frame = ttk.Frame(parent)
        grid_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Checkbutton(grid_frame, text="Uppercase letters", variable=self.var_upper).grid(row=0, column=0, sticky=tk.W, pady=4, padx=(0, 20))
        ttk.Checkbutton(grid_frame, text="Lowercase letters", variable=self.var_lower).grid(row=0, column=1, sticky=tk.W, pady=4)
        ttk.Checkbutton(grid_frame, text="Numbers", variable=self.var_numbers).grid(row=1, column=0, sticky=tk.W, pady=4, padx=(0, 20))
        ttk.Checkbutton(grid_frame, text="Symbols", variable=self.var_symbols).grid(row=1, column=1, sticky=tk.W, pady=4)
        
        self.var_exclude = tk.BooleanVar(value=False)
        ttk.Checkbutton(parent, text="Avoid confusing characters (0, O, l, 1)", variable=self.var_exclude).pack(anchor=tk.W)

    def _build_result_section(self, parent):
        ttk.Label(parent, text="Your Password", style="Section.TLabel").pack(anchor=tk.W, pady=(0, 5))
        
        self.password_var = tk.StringVar()
        
        # Clean, human-friendly entry box
        password_entry = tk.Entry(
            parent, 
            textvariable=self.password_var, 
            font=("Consolas", 14), 
            state="readonly", 
            justify="center", 
            bg="#ffffff", 
            fg="#2c3e50",
            relief="solid",
            borderwidth=1
        )
        password_entry.pack(fill=tk.X, pady=(0, 10), ipady=6)
        
        strength_frame = ttk.Frame(parent)
        strength_frame.pack(fill=tk.X)
        
        ttk.Label(strength_frame, text="Strength:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.strength_label = ttk.Label(strength_frame, text="-", style="Strength.TLabel")
        self.strength_label.pack(side=tk.LEFT)
        
        self.strength_canvas = tk.Canvas(strength_frame, width=150, height=12, bg="#e0e0e0", highlightthickness=0)
        self.strength_canvas.pack(side=tk.RIGHT, pady=4)

    def _build_buttons_section(self, parent):
        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, pady=(20, 0))
        
        # Primary actions
        primary_frame = ttk.Frame(btn_frame)
        primary_frame.pack(fill=tk.X, pady=(0, 15))
        
        ttk.Button(primary_frame, text="Generate Password", style="Generate.TButton", command=self.generate).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        ttk.Button(primary_frame, text="Copy Password", command=self.copy_to_clipboard).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        
        ttk.Separator(btn_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=(0, 15))
        
        # Secondary actions
        secondary_frame = ttk.Frame(btn_frame)
        secondary_frame.pack(fill=tk.X)
        
        ttk.Button(secondary_frame, text="View History", command=self.view_history).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        ttk.Button(secondary_frame, text="Clear", command=self.clear_fields).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))

    # --- Button Callbacks and Logic ---

    def copy_to_clipboard(self, silent=False):
        password = self.password_var.get()
        if password:
            try:
                pyperclip.copy(password)
                if not silent:
                    messagebox.showinfo("Success", "Copied to clipboard.", parent=self.root)
            except pyperclip.PyperclipException as e:
                if not silent:
                    messagebox.showerror("Error", f"Clipboard unavailable: {e}", parent=self.root)
            except Exception as e:
                if not silent:
                    messagebox.showerror("Error", f"Could not copy: {e}", parent=self.root)
        else:
            if not silent:
                messagebox.showwarning("Warning", "Please generate a password first.", parent=self.root)
            
    def clear_fields(self):
        self.password_var.set("")
        
        self.strength_label.config(text="-", foreground="black")
        self.strength_canvas.delete("all")
        
        try:
            self.length_var.set(16)
        except tk.TclError:
            pass
        
        self.var_upper.set(True)
        self.var_lower.set(True)
        self.var_numbers.set(True)
        self.var_symbols.set(True)
        self.var_exclude.set(False)

    def view_history(self):
        history_win = tk.Toplevel(self.root)
        history_win.title("Password History")
        history_win.geometry("550x300")
        history_win.minsize(500, 250)
        
        history_win.transient(self.root)
        history_win.grab_set()
        history_win.configure(bg="#f8f9fa")
        
        main_frame = ttk.Frame(history_win, padding="15")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(main_frame, text="Recent Passwords (Session Only)", font=("Segoe UI", 12, "bold")).pack(anchor=tk.W, pady=(0, 10))
        
        # Create Treeview for history table
        columns = ("#", "Password", "Strength", "Generated At")
        self.history_tree = ttk.Treeview(main_frame, columns=columns, show="headings", height=5)
        
        self.history_tree.heading("#", text="#")
        self.history_tree.heading("Password", text="Password")
        self.history_tree.heading("Strength", text="Strength")
        self.history_tree.heading("Generated At", text="Generated At")
        
        self.history_tree.column("#", width=30, anchor=tk.CENTER)
        self.history_tree.column("Password", width=220, anchor=tk.W)
        self.history_tree.column("Strength", width=80, anchor=tk.CENTER)
        self.history_tree.column("Generated At", width=150, anchor=tk.CENTER)
        
        # Configure treeview fonts
        style = ttk.Style()
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))
        style.configure("Treeview", font=("Consolas", 10), rowheight=25)
        
        self.history_tree.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        for i, (pw, strength, timestamp) in enumerate(self.history, 1):
            self.history_tree.insert("", tk.END, values=(i, pw, strength, timestamp))
            
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=(15, 0))
        
        ttk.Button(btn_frame, text="Copy Selected", command=lambda: self.copy_from_history(history_win)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btn_frame, text="Close", command=history_win.destroy).pack(side=tk.RIGHT)

    def copy_from_history(self, window):
        if not self.history:
            return
            
        try:
            selected_item = self.history_tree.selection()
            if not selected_item:
                messagebox.showwarning("Warning", "Please select a password from the list.", parent=window)
                return
                
            # Get the password column (index 1)
            item_values = self.history_tree.item(selected_item[0], "values")
            selected_password = item_values[1]
            
            pyperclip.copy(selected_password)
            messagebox.showinfo("Success", "Copied to clipboard.", parent=window)
        except pyperclip.PyperclipException as e:
            messagebox.showerror("Error", f"Clipboard unavailable: {e}", parent=window)
        except Exception as e:
            messagebox.showerror("Error", f"Could not copy: {e}", parent=window)

    def generate(self):
        try:
            length_str = str(self.length_var.get())
            use_upper = self.var_upper.get()
            use_lower = self.var_lower.get()
            use_numbers = self.var_numbers.get()
            use_symbols = self.var_symbols.get()
            use_exclude = self.var_exclude.get()
        except tk.TclError:
            messagebox.showerror("Error", "Password length must be a valid number.", parent=self.root)
            return
        
        is_valid, error_msg, length = validate_password_options(
            length_str, use_upper, use_lower, use_numbers, use_symbols
        )
        
        if not is_valid:
            messagebox.showerror("Notice", error_msg, parent=self.root)
            return
            
        try:
            password = generate_password(length, use_upper, use_lower, use_numbers, use_symbols, use_exclude)
        except ValueError as e:
            messagebox.showerror("Configuration Error", str(e), parent=self.root)
            return
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred: {str(e)}", parent=self.root)
            return
            
        try:
            strength_text, color_hex, percentage = evaluate_password_strength(password)
        except Exception as e:
            messagebox.showerror("Error", f"Could not evaluate strength: {str(e)}", parent=self.root)
            return
        
        try:
            self.password_var.set(password)
            self.strength_label.config(text=strength_text, foreground=color_hex)
            
            self.strength_canvas.delete("all")
            width = (percentage / 100) * 150
            self.strength_canvas.create_rectangle(0, 0, width, 12, fill=color_hex, outline="")
        except tk.TclError as e:
            messagebox.showerror("Error", f"Failed to update display: {e}", parent=self.root)
            return
        
        self.copy_to_clipboard(silent=True)
            
        # Append tuple of (password, strength, timestamp) to history
        timestamp = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
        self.history.insert(0, (password, strength_text, timestamp))
        if len(self.history) > 5:
            self.history.pop()

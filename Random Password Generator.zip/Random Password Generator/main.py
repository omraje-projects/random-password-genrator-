import tkinter as tk
from gui import PasswordGeneratorApp

def main():
    # Fix blurry fonts on Windows by enabling DPI awareness
    try:
        from ctypes import windll
        windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

    root = tk.Tk()
    app = PasswordGeneratorApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()

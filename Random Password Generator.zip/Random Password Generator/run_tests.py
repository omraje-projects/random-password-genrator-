import string
from validation import validate_password_options
from generator import generate_password
from strength import evaluate_password_strength

print("--- AUTOMATED TEST SUITE ---\n")

def assert_test(name, expected, actual):
    status = "PASS" if expected == actual else "FAIL"
    print(f"[{status}] {name}")
    if status == "FAIL":
        print(f"   Expected: {expected}, Got: {actual}")

# 1-10 Validation Tests
is_valid, msg, _ = validate_password_options("16", True, True, True, True)
assert_test("Default password generation", True, is_valid)

is_valid, msg, _ = validate_password_options("8", True, True, True, True)
assert_test("Minimum length of 8", True, is_valid)

is_valid, msg, _ = validate_password_options("128", True, True, True, True)
assert_test("Maximum length of 128", True, is_valid)

is_valid, msg, _ = validate_password_options("abc", True, True, True, True)
assert_test("Invalid length (string)", False, is_valid)

is_valid, msg, _ = validate_password_options("7", True, True, True, True)
assert_test("Length below 8", False, is_valid)

is_valid, msg, _ = validate_password_options("16", True, False, False, False)
assert_test("Uppercase only (fails validation)", False, is_valid)

is_valid, msg, _ = validate_password_options("16", False, True, False, False)
assert_test("Lowercase only (fails validation)", False, is_valid)

is_valid, msg, _ = validate_password_options("16", False, False, True, False)
assert_test("Numbers only (fails validation)", False, is_valid)

is_valid, msg, _ = validate_password_options("16", False, False, False, True)
assert_test("Symbols only (fails validation)", False, is_valid)

is_valid, msg, _ = validate_password_options("16", False, False, False, False)
assert_test("No types selected", False, is_valid)

# 11-15 Generation Tests (Diversity & Exclusions)
def check_diversity(pw, u, l, n, s):
    has_u = any(c in string.ascii_uppercase for c in pw) if u else not any(c in string.ascii_uppercase for c in pw)
    has_l = any(c in string.ascii_lowercase for c in pw) if l else not any(c in string.ascii_lowercase for c in pw)
    has_n = any(c in string.digits for c in pw) if n else not any(c in string.digits for c in pw)
    has_s = any(c in "!@#$%^&*()-_=+[]{};:,.?/" for c in pw) if s else not any(c in "!@#$%^&*()-_=+[]{};:,.?/" for c in pw)
    return has_u and has_l and has_n and has_s

pw = generate_password(8, True, True, False, False, False)
assert_test("Uppercase + lowercase diversity", True, check_diversity(pw, True, True, False, False))

pw = generate_password(8, True, False, True, False, False)
assert_test("Uppercase + numbers diversity", True, check_diversity(pw, True, False, True, False))

pw = generate_password(8, False, True, True, False, False)
assert_test("Lowercase + numbers diversity", True, check_diversity(pw, False, True, True, False))

pw = generate_password(8, True, True, True, True, False)
assert_test("All four types diversity", True, check_diversity(pw, True, True, True, True))

# 15. Guaranteed Character Diversity
diversity_passed = True
for _ in range(500):
    pw = generate_password(16, True, True, True, True, False)
    if not check_diversity(pw, True, True, True, True):
        diversity_passed = False
        break
assert_test("Guaranteed character diversity (500 runs)", True, diversity_passed)

# 16-17. Ambiguous Characters
ambig = "0O1l"
pw = generate_password(100, True, True, True, True, True)
assert_test("Exclude ambiguous characters enabled", False, any(c in ambig for c in pw))

pw = generate_password(100, True, True, True, True, False)
# By probability, 100 length password will almost certainly contain at least one of 0O1l
assert_test("Exclude ambiguous characters disabled", True, any(c in ambig for c in pw))

# 18. Password Strength Calculation
text, color, pct = evaluate_password_strength(generate_password(8, True, True, False, False, False))
assert_test("Strength: 8 chars, 2 types -> Medium", "Medium", text)

text, color, pct = evaluate_password_strength(generate_password(12, True, True, True, False, False))
assert_test("Strength: 12 chars, 3 types -> Strong", "Strong", text)

# Simulate short password manually since generation blocks < 8
text, color, pct = evaluate_password_strength("ab12")
assert_test("Strength: 4 chars, 2 types -> Weak", "Weak", text)

print("\n--- ALL TESTS COMPLETED ---")

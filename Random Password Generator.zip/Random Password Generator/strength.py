import string

def evaluate_password_strength(password):
    """
    Analyzes the generated password and estimates its strength based on 
    length and character diversity.
    
    IMPORTANT:
    This strength indicator is not a mathematically perfect security measurement 
    (like entropy calculation or checking against known breached passwords). 
    It is only a simple user-facing estimate to guide users toward better practices.
    
    Returns:
        tuple: (Strength text, color hex code, progress percentage)
    """
    length = len(password)
    
    has_lower = any(c in string.ascii_lowercase for c in password)
    has_upper = any(c in string.ascii_uppercase for c in password)
    has_digits = any(c in string.digits for c in password)
    has_symbols = any(c in "!@#$%^&*()-_=+[]{};:,.?/" for c in password)
    
    types_count = sum([has_lower, has_upper, has_digits, has_symbols])
    
    # STRONG: Length of at least 12 characters, good character diversity
    if length >= 12 and types_count >= 3:
        return "Strong", "#27ae60", 100  # Green, 100%
        
    # MEDIUM: Reasonable length, multiple character types
    elif length >= 8 and types_count >= 2:
        return "Medium", "#f39c12", 66   # Orange, 66%
        
    # WEAK: Shorter passwords, low character diversity
    else:
        return "Weak", "#c0392b", 33     # Red, 33%

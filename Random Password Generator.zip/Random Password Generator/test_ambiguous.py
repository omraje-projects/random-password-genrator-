from generator import generate_password

def test_ambiguous_characters():
    ambiguous_set = set("0O1l")
    
    print("Running 1,000 password generation tests...\n")
    
    # Test 1: Disabled
    found_ambiguous = False
    for _ in range(1000):
        pw = generate_password(128, True, True, True, True, False)
        if any(c in ambiguous_set for c in pw):
            found_ambiguous = True
            break
            
    print(f"TEST 1: Without exclusion (False)")
    print(f"Did we find ambiguous characters? -> {found_ambiguous}")
    print(f"Sample: {pw[:30]}...\n")
    
    # Test 2: Enabled
    found_ambiguous = False
    for _ in range(1000):
        pw = generate_password(128, True, True, True, True, True)
        if any(c in ambiguous_set for c in pw):
            found_ambiguous = True
            break
            
    print(f"TEST 2: With exclusion (True)")
    print(f"Did we find ambiguous characters? -> {found_ambiguous}")
    print(f"Sample: {pw[:30]}...\n")

if __name__ == "__main__":
    test_ambiguous_characters()

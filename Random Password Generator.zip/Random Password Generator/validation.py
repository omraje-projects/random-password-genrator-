def validate_password_options(length_str, use_upper, use_lower, use_numbers, use_symbols):
    """
    Validates password length and selected character types.
    Returns (is_valid, error_message, validated_length)
    """
    try:
        length = int(length_str)
    except ValueError:
        return False, "Password length must be a valid number.", None
    
    if length < 8:
        return False, "Password length must be at least 8 characters.", None
        
    if length > 128:
        return False, "Password length must be between 8 and 128 characters.", None
    
    types_selected = sum([bool(use_upper), bool(use_lower), bool(use_numbers), bool(use_symbols)])
    if types_selected < 2:
        return False, "Please select at least two character types.", None
        
    return True, None, length
